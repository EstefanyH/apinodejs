class FusionData {
    constructor(id, planet, climate, population, weather, temperature) {
        this.id = id;
        this.planet = planet;
        this.climate = climate;
        this.population = population;
        this.weather = weather;
        this.temperature = temperature;
    }
}

export default FusionData;